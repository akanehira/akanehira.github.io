===========================================
The Viewpoint-aware Video Summarization Dataset
===========================================

This is the dataset presented in the paper ``Viewpoint-aware Video Summarization.'' at CVPR'18.

  http://akanehira.github.io/papers/viewpoint.pdf

If you use the dataset in a publication, please cite the above paper.

This directory include 4 csv files, i.e., group_name.csv, concept_name.csv, video_ID.csv, labels.csv,
each of which contains following information;

------- group_name.csv -------
The list of group names used for collecting videos.
Each row corresponds to that of  Table.1 in the main paper.

<concept>,<target_group>,<related_group1>,<related_group2>
------------------------------

------- concept_name.csv -------
The list of concepts used for annotating importance score to videos belonging to target groups.
Each of row corresponds to that written in Table.1 in the main paper.

<concept>,<target_group>,<concept1>,<concept2>
--------------------------------

------- video_ID.csv -------
The list of video ID.
Video can be found at https://www.youtube.com/watch?v=<video ID>

<concept>,<target_group>,<concept1>,<concept2>
--------------------------------

------- labels.csv -------
Importance score of videos annotated by AMT workers.
For detail information about the setting of annotation, please refer the main paper.

<concept No>,<class_name>,<concept>,<video ID>,<label>
--------------------------------
